USER_SERVICE = "user_service"
SESSION_SERVICE = "session_service"
MAIL_SERVICE = "mail_service"