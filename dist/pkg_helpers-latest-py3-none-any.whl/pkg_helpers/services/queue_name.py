USER_QUEUE = "user_queue"
SESSION_QUEUE = "session_queue"
MAIL_QUEUE = "mail_queue"