USER_ROUTE = "user-service"
SESSION_ROUTE = "session-service"
MAIL_ROUTE = "mail-service"