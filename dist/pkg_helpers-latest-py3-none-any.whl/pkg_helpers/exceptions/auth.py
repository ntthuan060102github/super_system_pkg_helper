class UnVerifiedException(Exception): 
    pass